
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { readingAI, AiResponse } from './services/aiProcessor';
import { Book, UserStats } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'home' | 'reader' | 'coach' | 'stats'>('home');
  
  const [books, setBooks] = useState<Book[]>(() => {
    const saved = localStorage.getItem('rm_books_v4');
    return saved ? JSON.parse(saved) : [
      { 
        id: '1', 
        title: 'Dom Casmurro', 
        author: 'Machado de Assis', 
        totalPages: 256, 
        currentPage: 45, 
        category: 'Sincronizado', 
        coverUrl: 'https://play.google.com/store/books/details/Machado_de_Assis_Dom_Casmurro?id=v-0DAAAAYAAJ', 
        summary: 'Uma obra-prima do realismo que questiona a fidelidade e a memória através do ciúme obsessivo de Bentinho.',
        addedAt: Date.now() 
      }
    ];
  });

  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('rm_stats_v4');
    return saved ? JSON.parse(saved) : { 
      dailyGoalMinutes: 30, 
      minutesReadToday: 0,
      currentStreak: 5, 
      totalBooksFinished: 12, 
      pagesThisWeek: 184 
    };
  });

  const [noteText, setNoteText] = useState(() => localStorage.getItem('rm_draft_note') || '');
  const [summary, setSummary] = useState<string | null>(() => localStorage.getItem('rm_last_summary'));
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [timerActive, setTimerActive] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(stats.dailyGoalMinutes * 60);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [lastSources, setLastSources] = useState<any[]>([]);

  // Persistência
  useEffect(() => { localStorage.setItem('rm_books_v4', JSON.stringify(books)); }, [books]);
  useEffect(() => { localStorage.setItem('rm_stats_v4', JSON.stringify(stats)); }, [stats]);

  // Lógica de Resumo Automático (Notas)
  useEffect(() => {
    if (noteText.length > 50 && !isAiThinking) {
      const debounce = setTimeout(async () => {
        setIsAiThinking(true);
        try {
          const activeBook = books[0] || { title: 'Ativo', author: 'Explorador' };
          const res = await readingAI.summarizeReading(noteText, activeBook as Book);
          setSummary(res);
          localStorage.setItem('rm_last_summary', res);
        } finally {
          setIsAiThinking(false);
        }
      }, 3000);
      return () => clearTimeout(debounce);
    }
  }, [noteText]);

  // Lógica do Timer e Acúmulo de tempo diário
  useEffect(() => {
    let interval: number;
    if (timerActive && secondsLeft > 0) {
      interval = window.setInterval(() => {
        setSecondsLeft(s => s - 1);
        // A cada 60 segundos, incrementa o tempo lido hoje
        if (secondsLeft % 60 === 0) {
          setStats(prev => ({ ...prev, minutesReadToday: prev.minutesReadToday + 1 }));
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timerActive, secondsLeft]);

  const handleSyncBook = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    setSyncError(null);
    try {
      const { data, sources } = await readingAI.searchBookOnGooglePlay(searchQuery);
      if (data) {
        const bookId = Math.random().toString(36).substr(2, 9);
        const newBook: Book = {
          id: bookId,
          title: data.title,
          author: data.author,
          totalPages: data.totalPages,
          currentPage: 0,
          category: 'Play Books Echo',
          coverUrl: data.playStoreUri,
          summary: undefined, 
          addedAt: Date.now()
        };
        setBooks(prev => [newBook, ...prev]);
        setLastSources(sources);
        setSearchQuery('');
        setIsAddModalOpen(false);
        generateAsyncSummary(bookId, data.title, data.author);
      }
    } catch (error: any) {
      setSyncError(error.message || "Erro na sincronização.");
    } finally {
      setIsSearching(false);
    }
  };

  const generateAsyncSummary = async (id: string, title: string, author: string) => {
    try {
      const aiBookSummary = await readingAI.generateBookSummary(title, author);
      setBooks(prev => prev.map(b => b.id === id ? { ...b, summary: aiBookSummary } : b));
    } catch (e) {
      setBooks(prev => prev.map(b => b.id === id ? { ...b, summary: "Resumo indisponível." } : b));
    }
  };

  const handleUpdatePage = (bookId: string) => {
    const val = prompt("Qual a página atual?");
    if (val && !isNaN(parseInt(val))) {
      setBooks(prev => prev.map(b => b.id === bookId ? { ...b, currentPage: Math.min(parseInt(val), b.totalPages) } : b));
    }
  };

  const dailyProgress = Math.min((stats.minutesReadToday / stats.dailyGoalMinutes) * 100, 100);

  const renderHome = () => (
    <div className="space-y-8 animate-in fade-in duration-700">
      <header className="flex justify-between items-start">
        <div className="space-y-1">
          <h1 className="text-4xl font-black font-orbitron text-white italic tracking-tighter">PLAY <span className="text-cyan-400">SYNC</span></h1>
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span> Sistema de Retenção Ativo
          </p>
        </div>
        <div className="glass-panel p-3 rounded-2xl border-cyan-500/30">
          <span className="text-xl font-black">🔥 {stats.currentStreak}d</span>
        </div>
      </header>

      {/* Widget de Progresso Diário */}
      <div className="glass-panel rounded-[40px] p-8 border-l-8 border-l-cyan-500 relative overflow-hidden group">
        <div className="flex justify-between items-end mb-6">
          <div>
            <h2 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-2">Meta Diária</h2>
            <div className="text-3xl font-black font-orbitron text-white">
              {stats.minutesReadToday} <span className="text-cyan-500">/ {stats.dailyGoalMinutes}</span>
              <span className="text-xs font-normal text-slate-500 ml-2">min</span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-2xl font-black font-orbitron text-cyan-400">{Math.round(dailyProgress)}%</span>
          </div>
        </div>
        <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden border border-white/5">
          <div 
            className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400 shadow-[0_0_20px_#06b6d4] transition-all duration-1000" 
            style={{ width: `${dailyProgress}%` }}
          ></div>
        </div>
        <div className="mt-4 flex justify-between text-[9px] font-black text-slate-500 uppercase italic tracking-widest">
          <span>Início do Ciclo</span>
          <span>{stats.dailyGoalMinutes - stats.minutesReadToday} min restantes</span>
        </div>
      </div>

      {/* Library */}
      <section className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-sm font-black font-orbitron text-slate-300 uppercase italic">Biblioteca Neural</h2>
          <button onClick={() => { setSyncError(null); setIsAddModalOpen(true); }} className="px-4 py-2 bg-white text-black text-[10px] font-black rounded-full hover:scale-105 transition-all uppercase italic">Novo Link</button>
        </div>
        <div className="grid gap-6">
          {books.map((book, index) => {
            const bookPercent = Math.round((book.currentPage / book.totalPages) * 100);
            return (
              <div 
                key={book.id} 
                className="glass-panel p-6 rounded-[35px] flex flex-col gap-5 hover:border-cyan-500/50 transition-all group relative animate-pop-in border-white/5"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="flex items-center gap-5">
                  <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center border border-white/10 group-hover:neon-glow-cyan transition-all flex-shrink-0 cursor-pointer" onClick={() => handleUpdatePage(book.id)}>
                    <i data-lucide="book-open" className="text-cyan-500 w-6 h-6"></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-1">
                       <h3 className="font-bold text-white text-sm truncate uppercase tracking-tight pr-2">{book.title}</h3>
                       <span className="text-[10px] font-black font-orbitron text-cyan-400">{bookPercent}%</span>
                    </div>
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-3">{book.author}</p>
                    <div className="h-2 w-full bg-slate-800/50 rounded-full overflow-hidden">
                      <div className="h-full bg-cyan-500 shadow-[0_0_15px_#06b6d4] transition-all duration-700" style={{width: `${bookPercent}%`}}></div>
                    </div>
                    <div className="mt-2 flex justify-between text-[8px] font-bold text-slate-600 uppercase">
                      <span>Pág {book.currentPage}</span>
                      <span>Total {book.totalPages}</span>
                    </div>
                  </div>
                </div>
                
                {/* AI Summary Section */}
                <div className="relative p-4 bg-white/5 border border-white/5 rounded-2xl min-h-[60px] flex items-center group/summary">
                  {!book.summary ? (
                    <div className="w-full space-y-2 opacity-50">
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-pulse"></div>
                        <span className="text-[7px] font-black text-cyan-500 uppercase tracking-tighter italic">Deep Scan...</span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-[10px] text-slate-400 leading-relaxed italic animate-in fade-in duration-1000">
                      <span className="text-cyan-500/50 font-black not-italic text-[8px] uppercase tracking-tighter mr-2">Core Insight:</span>
                      {book.summary}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col max-w-md mx-auto relative bg-[#010310] overflow-hidden">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none opacity-40">
        <div className="absolute top-0 right-0 w-[80%] h-[400px] bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.15)_0%,transparent_70%)]"></div>
        <div className="absolute bottom-0 left-0 w-[60%] h-[300px] bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.1)_0%,transparent_70%)]"></div>
      </div>

      <main className="flex-1 overflow-y-auto pb-40 pt-10 px-8 z-10 scrollbar-hide">
        {activeTab === 'home' && renderHome()}
        
        {activeTab === 'reader' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-8 duration-700">
             <div className="text-center">
                <h2 className="text-2xl font-black font-orbitron text-white italic tracking-tighter uppercase