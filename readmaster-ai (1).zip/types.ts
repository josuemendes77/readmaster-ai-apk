
export interface Book {
  id: string;
  title: string;
  author: string;
  totalPages: number;
  currentPage: number;
  category: string;
  coverUrl?: string;
  summary?: string; // Resumo automático gerado pela IA
  addedAt: number;
}

export interface ReadingSession {
  id: string;
  bookId: string;
  durationMinutes: number;
  pagesRead: number;
  timestamp: number;
}

export interface Note {
  id: string;
  bookId: string;
  content: string;
  aiSummary?: string;
  timestamp: number;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  nextReview: number;
}

export interface UserStats {
  dailyGoalMinutes: number;
  minutesReadToday: number; // Novo campo para tempo real lido hoje
  currentStreak: number;
  totalBooksFinished: number;
  pagesThisWeek: number;
}

export enum DeckId {
  A = 'A',
  B = 'B'
}

export enum AudioStem {
  MIX = 'MIX',
  VOCAL = 'VOCAL',
  INSTRUMENTAL = 'INSTRUMENTAL'
}

export interface StemParameters {
  vocalCenter: number;
  vocalWidth: number;
  instNotch: number;
  instDepth: number;
}
