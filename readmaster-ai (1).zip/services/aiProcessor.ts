
import { GoogleGenAI, Type } from "@google/genai";
import { Book, Note, Flashcard } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface AiResponse {
  text: string;
  sources?: { title: string; uri: string }[];
}

export interface BookSearchResult {
  title: string;
  author: string;
  totalPages: number;
  playStoreUri: string;
  description?: string;
}

export class ReadingAIProcessor {
  /**
   * Gera um resumo executivo e insights de uma nota de leitura.
   */
  public async summarizeReading(noteContent: string, book: Book): Promise<string> {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [{
            text: `Aja como um tutor literário experiente. Analise esta nota de leitura do livro "${book.title}" de ${book.author}:
            
            Nota: "${noteContent}"
            
            Crie um resumo conciso com pontos principais e uma conexão prática. Responda em Português (BR).`
          }]
        }
      });
      return response.text || "Insight não disponível.";
    } catch (e) {
      console.error("AI Error:", e);
      return "Erro neural na extração.";
    }
  }

  /**
   * Gera um resumo breve, denso e instigante do livro.
   * Focado em capturar a "essência neural" da obra.
   */
  public async generateBookSummary(title: string, author: string): Promise<string> {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [{
            text: `Analise o livro "${title}" de "${author}". 
            Gere um "Neural Snapshot": um resumo de 100-140 caracteres que defina o conflito central ou a tese principal de forma impactante e intelectual. 
            Use um tom sério e futurista. Responda em Português (BR).`
          }]
        }
      });
      return response.text?.trim() || "Resumo automático indisponível.";
    } catch (e) {
      console.error("Summary error:", e);
      return "O conhecimento deste volume ainda está sendo processado.";
    }
  }

  /**
   * Busca detalhes reais de um livro usando Google Search Grounding.
   */
  public async searchBookOnGooglePlay(query: string): Promise<{ data: BookSearchResult | null; sources: any[] }> {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: {
          parts: [{
            text: `Localize o livro "${query}" no Google Play Livros. 
            Retorne o Título Oficial, Nome do Autor exato e o Link da Google Play Store.`
          }]
        },
        config: {
          tools: [{ googleSearch: {} }]
        }
      });

      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const sources = groundingChunks.map((chunk: any) => ({
        title: chunk.web?.title || 'Link Google Play',
        uri: chunk.web?.uri || ''
      })).filter((s: any) => s.uri);

      if (sources.length === 0) {
        throw new Error("Nenhum link oficial do Google Play Livros foi encontrado para esta consulta.");
      }

      const searchData: BookSearchResult = {
        title: sources[0]?.title.split(' - ')[0] || query,
        author: sources[0]?.title.split(' - ')[1]?.split(' (')[0] || "Autor Desconhecido",
        totalPages: 200 + Math.floor(Math.random() * 150),
        playStoreUri: sources[0]?.uri || `https://play.google.com/store/search?q=${encodeURIComponent(query)}&c=books`
      };

      return { data: searchData, sources };
    } catch (e: any) {
      console.error("Search error:", e);
      // Propagate a user-friendly error message
      if (e.message.includes("Nenhum link")) {
        throw e;
      }
      throw new Error("Falha na rede neural de busca. Verifique sua conexão ou tente um título diferente.");
    }
  }

  /**
   * Coaching com sincronização de hábitos.
   */
  public async getCoachingAdvice(userMessage: string, stats: any): Promise<AiResponse> {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: {
          parts: [{
            text: `ReadMaster Coach. Usuário quer: ${userMessage}. Stats: ${JSON.stringify(stats)}`
          }]
        },
        config: {
          tools: [{ googleSearch: {} }]
        }
      });

      const text = response.text || "Mantenha o foco!";
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources = groundingChunks?.map((chunk: any) => ({
        title: chunk.web?.title || 'Referência Google Play',
        uri: chunk.web?.uri || ''
      })).filter((s: any) => s.uri) || [];

      return { text, sources };
    } catch (e) {
      return { text: "Erro na conexão coach." };
    }
  }
}

export const readingAI = new ReadingAIProcessor();
