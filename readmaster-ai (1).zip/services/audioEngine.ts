
import { DeckId, AudioStem, StemParameters } from '../types';

class DeckEngine {
  public context: AudioContext;
  public source: AudioBufferSourceNode | null = null;
  public buffer: AudioBuffer | null = null;
  
  private gainNode: GainNode;
  private pannerNode: StereoPannerNode;
  private eqLow: BiquadFilterNode;
  private eqMid: BiquadFilterNode;
  private eqHigh: BiquadFilterNode;
  private lpFilter: BiquadFilterNode;

  private mixNode: GainNode;
  private vocalNode: GainNode;
  private instNode: GainNode;
  
  private vocalFilter: BiquadFilterNode;
  private vocalHPF: BiquadFilterNode; 
  private instFilter: BiquadFilterNode;
  
  private startTime: number = 0;
  private pauseOffset: number = 0;
  private playbackRate: number = 1.0;
  private isPlaying: boolean = false;
  private isLooping: boolean = false;
  private loopStart: number = 0;
  private loopEnd: number = 0;

  constructor(context: AudioContext, destination: AudioNode) {
    this.context = context;
    this.gainNode = context.createGain();
    this.pannerNode = context.createStereoPanner();
    
    this.mixNode = context.createGain();
    this.vocalNode = context.createGain();
    this.instNode = context.createGain();

    this.vocalFilter = context.createBiquadFilter();
    this.vocalFilter.type = 'bandpass';
    this.vocalFilter.frequency.value = 1600;
    this.vocalFilter.Q.value = 1.0;

    this.vocalHPF = context.createBiquadFilter();
    this.vocalHPF.type = 'highpass';
    this.vocalHPF.frequency.value = 300; 
    
    this.instFilter = context.createBiquadFilter();
    this.instFilter.type = 'peaking'; 
    this.instFilter.frequency.value = 1500;
    this.instFilter.gain.value = -40;

    this.eqLow = context.createBiquadFilter();
    this.eqLow.type = 'lowshelf';
    this.eqLow.frequency.value = 320;

    this.eqMid = context.createBiquadFilter();
    this.eqMid.type = 'peaking';
    this.eqMid.frequency.value = 1000;

    this.eqHigh = context.createBiquadFilter();
    this.eqHigh.type = 'highshelf';
    this.eqHigh.frequency.value = 3200;

    this.lpFilter = context.createBiquadFilter();
    this.lpFilter.type = 'lowpass';
    this.lpFilter.frequency.value = 20000;

    // Routing
    this.mixNode.connect(this.eqLow);
    
    this.vocalNode.connect(this.vocalHPF);
    this.vocalHPF.connect(this.vocalFilter);
    this.vocalFilter.connect(this.eqLow);
    
    this.instNode.connect(this.instFilter);
    this.instFilter.connect(this.eqLow);

    this.eqLow.connect(this.eqMid);
    this.eqMid.connect(this.eqHigh);
    this.eqHigh.connect(this.lpFilter);
    this.lpFilter.connect(this.pannerNode);
    this.pannerNode.connect(this.gainNode);
    this.gainNode.connect(destination);

    this.setStem(AudioStem.MIX);
  }

  public updateStemParameters(params: StemParameters) {
    const ramp = 0.5;
    this.vocalFilter.frequency.setTargetAtTime(params.vocalCenter, this.context.currentTime, ramp);
    this.vocalFilter.Q.setTargetAtTime(params.vocalWidth, this.context.currentTime, ramp);
    this.instFilter.frequency.setTargetAtTime(params.instNotch, this.context.currentTime, ramp);
    this.instFilter.gain.setTargetAtTime(params.instDepth, this.context.currentTime, ramp);
  }

  public triggerSample(type: 'kick' | 'snare' | 'clap' | 'hihat') {
    const osc = this.context.createOscillator();
    const g = this.context.createGain();
    g.connect(this.lpFilter);
    const t = this.context.currentTime;

    if (type === 'kick') {
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(0.01, t + 0.5);
      g.gain.setValueAtTime(1, t);
      g.gain.exponentialRampToValueAtTime(0.01, t + 0.5);
      osc.start(t);
      osc.stop(t + 0.5);
    } else if (type === 'hihat') {
      const noise = this.context.createBufferSource();
      const buffer = this.context.createBuffer(1, this.context.sampleRate * 0.1, this.context.sampleRate);
      const data = buffer.getChannelData(0);
      for(let i=0; i<data.length; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = this.context.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 7000;
      noise.connect(filter);
      filter.connect(g);
      g.gain.setValueAtTime(0.3, t);
      g.gain.exponentialRampToValueAtTime(0.01, t + 0.05);
      noise.start(t);
    } else {
      osc.type = 'square';
      osc.frequency.setValueAtTime(type === 'snare' ? 200 : 400, t);
      g.gain.setValueAtTime(0.5, t);
      g.gain.exponentialRampToValueAtTime(0.01, t + 0.2);
      osc.start(t);
      osc.stop(t + 0.2);
    }
  }

  public setStem(stem: AudioStem) {
    const ramp = 0.15; 
    this.mixNode.gain.setTargetAtTime(stem === AudioStem.MIX ? 1.0 : 0, this.context.currentTime, ramp);
    this.vocalNode.gain.setTargetAtTime(stem === AudioStem.VOCAL ? 1.8 : 0, this.context.currentTime, ramp); 
    this.instNode.gain.setTargetAtTime(stem === AudioStem.INSTRUMENTAL ? 1.0 : 0, this.context.currentTime, ramp);
  }

  public getPitch() { return this.playbackRate; }
  public getBuffer() { return this.buffer; }

  public async loadTrack(url: string) {
    if (url === 'INTERNAL_DEMO') {
      const sr = this.context.sampleRate;
      this.buffer = this.context.createBuffer(2, sr * 30, sr);
      for(let c=0; c<2; c++) {
        const d = this.buffer.getChannelData(c);
        for(let i=0; i<d.length; i++) d[i] = (Math.random() * 2 - 1) * 0.05 * Math.pow(Math.sin(i/sr*Math.PI*2), 20);
      }
    } else {
      const r = await fetch(url);
      this.buffer = await this.context.decodeAudioData(await r.arrayBuffer());
    }
    this.stop();
    this.pauseOffset = 0;
    this.isLooping = false;
  }

  public play() {
    if (!this.buffer || this.isPlaying) return;
    this.source = this.context.createBufferSource();
    this.source.buffer = this.buffer;
    this.source.playbackRate.value = this.playbackRate;
    this.source.loop = this.isLooping;
    if (this.isLooping) {
      this.source.loopStart = this.loopStart;
      this.source.loopEnd = this.loopEnd;
    }
    this.source.connect(this.mixNode);
    this.source.connect(this.vocalNode);
    this.source.connect(this.instNode);
    this.source.start(0, this.pauseOffset);
    this.startTime = this.context.currentTime - (this.pauseOffset / this.playbackRate);
    this.isPlaying = true;
  }

  public stop() {
    if (this.source) { try{this.source.stop();}catch(e){} this.source.disconnect(); }
    this.isPlaying = false;
  }

  public togglePlay() { this.isPlaying ? (this.pauseOffset = this.getCurrentTime(), this.stop()) : this.play(); }

  public getCurrentTime() {
    if (!this.isPlaying) return this.pauseOffset;
    const elapsed = (this.context.currentTime - this.startTime) * this.playbackRate;
    if (this.isLooping && this.buffer) {
       // Calculation for looping playback time
       if (elapsed >= this.loopEnd) {
         const loopDuration = this.loopEnd - this.loopStart;
         return this.loopStart + ((elapsed - this.loopStart) % loopDuration);
       }
    }
    return elapsed % (this.buffer?.duration || 1);
  }

  public setPitch(v: number) {
    this.playbackRate = v;
    if (this.source) this.source.playbackRate.setTargetAtTime(v, this.context.currentTime, 0.01);
    this.startTime = this.context.currentTime - (this.getCurrentTime() / v);
  }

  public setEQ(b: any, g: number) {
    const n = b === 'low' ? this.eqLow : b === 'mid' ? this.eqMid : this.eqHigh;
    n.gain.setTargetAtTime(g, this.context.currentTime, 0.01);
  }

  public setFilter(f: number) { this.lpFilter.frequency.setTargetAtTime(f, this.context.currentTime, 0.01); }
  public jumpTo(t: number) { const p = this.isPlaying; this.stop(); this.pauseOffset = t; if(p) this.play(); }
  
  public toggleLoop(active: boolean, beats: number, trackBpm: number) {
    if (active) {
      const beatDuration = 60 / (trackBpm * this.playbackRate);
      const loopLen = beats * beatDuration;
      const start = this.getCurrentTime();
      this.isLooping = true;
      this.loopStart = start;
      this.loopEnd = start + loopLen;
      
      if (this.source) {
        this.source.loop = true;
        this.source.loopStart = this.loopStart;
        this.source.loopEnd = this.loopEnd;
      }
    } else {
      this.isLooping = false;
      if (this.source) {
        this.source.loop = false;
      }
    }
  }

  public getLoopState() { return { isLooping: this.isLooping, start: this.loopStart, end: this.loopEnd }; }
}

export class DJEngine {
  private context: AudioContext;
  private deckA: DeckEngine;
  private deckB: DeckEngine;
  private masterGain: GainNode;
  private xfA: GainNode;
  private xfB: GainNode;

  // Effects nodes
  private echoDelay: DelayNode;
  private echoFeedback: GainNode;
  private echoWet: GainNode;

  private reverbDelay: DelayNode; 
  private reverbWet: GainNode;

  private flangerDelay: DelayNode;
  private flangerOsc: OscillatorNode | null = null;
  private flangerWet: GainNode;

  private mediaRecorder: MediaRecorder | null = null;
  private chunks: Blob[] = [];

  constructor() {
    this.context = new (window.AudioContext || (window as any).webkitAudioContext)();
    this.masterGain = this.context.createGain();
    
    // Echo Setup
    this.echoDelay = this.context.createDelay(1.0);
    this.echoFeedback = this.context.createGain();
    this.echoWet = this.context.createGain();
    this.echoWet.gain.value = 0;
    this.echoFeedback.gain.value = 0.5;
    this.echoDelay.delayTime.value = 0.375;
    
    // Reverb Setup
    this.reverbDelay = this.context.createDelay(0.1);
    this.reverbWet = this.context.createGain();
    this.reverbWet.gain.value = 0;
    this.reverbDelay.delayTime.value = 0.05;

    // Flanger Setup
    this.flangerDelay = this.context.createDelay(0.01);
    this.flangerWet = this.context.createGain();
    this.flangerWet.gain.value = 0;
    
    this.masterGain.connect(this.context.destination);
    
    // Echo Route
    this.masterGain.connect(this.echoDelay);
    this.echoDelay.connect(this.echoFeedback);
    this.echoFeedback.connect(this.echoDelay);
    this.echoDelay.connect(this.echoWet);
    this.echoWet.connect(this.context.destination);

    // Reverb Route
    this.masterGain.connect(this.reverbDelay);
    this.reverbDelay.connect(this.reverbWet);
    this.reverbWet.connect(this.context.destination);

    // Flanger Route
    this.masterGain.connect(this.flangerDelay);
    this.flangerDelay.connect(this.flangerWet);
    this.flangerWet.connect(this.context.destination);

    this.xfA = this.context.createGain();
    this.xfB = this.context.createGain();
    this.xfA.connect(this.masterGain);
    this.xfB.connect(this.masterGain);
    
    this.deckA = new DeckEngine(this.context, this.xfA);
    this.deckB = new DeckEngine(this.context, this.xfB);
    
    this.setCrossfader(0.5);
  }

  public getDeck(id: DeckId) { return id === DeckId.A ? this.deckA : this.deckB; }
  
  public setCrossfader(v: number) {
    this.xfA.gain.setTargetAtTime(Math.cos(v * Math.PI / 2), this.context.currentTime, 0.01);
    this.xfB.gain.setTargetAtTime(Math.sin(v * Math.PI / 2), this.context.currentTime, 0.01);
  }
  
  public setMasterVolume(v: number) { 
    this.masterGain.gain.setTargetAtTime(v, this.context.currentTime, 0.01); 
  }

  public setEcho(enabled: boolean, intensity: number) {
    const wet = enabled ? intensity * 0.7 : 0;
    this.echoWet.gain.setTargetAtTime(wet, this.context.currentTime, 0.05);
    this.echoFeedback.gain.setTargetAtTime(intensity * 0.6, this.context.currentTime, 0.05);
  }

  public setReverb(enabled: boolean, intensity: number) {
    const wet = enabled ? intensity * 0.8 : 0;
    this.reverbWet.gain.setTargetAtTime(wet, this.context.currentTime, 0.05);
  }

  public setFlanger(enabled: boolean, intensity: number) {
    const wet = enabled ? intensity * 0.6 : 0;
    this.flangerWet.gain.setTargetAtTime(wet, this.context.currentTime, 0.05);
    
    if (enabled && !this.flangerOsc) {
      this.flangerOsc = this.context.createOscillator();
      const lfoGain = this.context.createGain();
      this.flangerOsc.frequency.value = 0.25;
      lfoGain.gain.value = 0.005;
      this.flangerOsc.connect(lfoGain);
      lfoGain.connect(this.flangerDelay.delayTime);
      this.flangerOsc.start();
    } else if (!enabled && this.flangerOsc) {
      this.flangerOsc.stop();
      this.flangerOsc.disconnect();
      this.flangerOsc = null;
    }
  }

  public resumeContext() { if(this.context.state === 'suspended') this.context.resume(); }

  public startRecording() {
    const dest = this.context.createMediaStreamDestination();
    this.masterGain.connect(dest);
    this.mediaRecorder = new MediaRecorder(dest.stream);
    this.chunks = [];
    this.mediaRecorder.ondataavailable = (e) => this.chunks.push(e.data);
    this.mediaRecorder.start();
  }

  public stopRecording(): Promise<Blob> {
    return new Promise(r => {
      if(!this.mediaRecorder) return r(new Blob());
      this.mediaRecorder.onstop = () => r(new Blob(this.chunks, {type: 'audio/webm'}));
      this.mediaRecorder.stop();
    });
  }
}

export const audioEngine = new DJEngine();
