
import { Book } from '../types';

const STORAGE_KEY = 'readmaster_ai_books';

export const storage = {
  getBooks: (): Book[] => {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveBooks: (books: Book[]): void => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
  },

  addBook: (book: Book): void => {
    const books = storage.getBooks();
    books.push(book);
    storage.saveBooks(books);
  },

  updateBook: (updatedBook: Book): void => {
    const books = storage.getBooks();
    const index = books.findIndex(b => b.id === updatedBook.id);
    if (index !== -1) {
      books[index] = updatedBook;
      storage.saveBooks(books);
    }
  },

  deleteBook: (id: string): void => {
    const books = storage.getBooks().filter(b => b.id !== id);
    storage.saveBooks(books);
  }
};
