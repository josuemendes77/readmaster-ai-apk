
import { GoogleGenAI, Type } from "@google/genai";
import { Summary } from "../types";

export const generateChapterSummary = async (chapterText: string): Promise<Summary> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key não configurada.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const prompt = `
    Você é um assistente de leitura especializado da plataforma ReadMaster AI.
    Analise o texto do capítulo abaixo e gere um resumo estruturado seguindo estas regras rigorosas:
    1. O resumo deve ter exatamente 10 tópicos (bullet points) principais sobre os acontecimentos.
    2. Após os tópicos, inclua um parágrafo final de conclusão sintetizando a importância do capítulo.
    3. Use Português do Brasil claro e objetivo.
    4. Não inclua introduções como "Aqui está o resumo". Vá direto ao ponto.

    TEXTO DO CAPÍTULO:
    ${chapterText}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            bulletPoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Lista de 10 tópicos principais do capítulo"
            },
            finalParagraph: {
              type: Type.STRING,
              description: "Um parágrafo final de conclusão"
            }
          },
          required: ["bulletPoints", "finalParagraph"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      bulletPoints: result.bulletPoints || [],
      finalParagraph: result.finalParagraph || "",
      generatedAt: Date.now()
    };
  } catch (error) {
    console.error("Erro ao gerar resumo Gemini:", error);
    throw error;
  }
};
