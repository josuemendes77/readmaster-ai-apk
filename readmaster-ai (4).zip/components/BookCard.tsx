
import React from 'react';
import { Book } from '../types';

interface BookCardProps {
  book: Book;
  onClick: () => void;
}

const BookCard: React.FC<BookCardProps> = ({ book, onClick }) => {
  const completedChapters = book.chapters.filter(c => c.isCompleted).length;
  const progress = book.chapters.length > 0 ? Math.round((completedChapters / book.chapters.length) * 100) : 0;

  return (
    <div 
      onClick={onClick}
      className="bg-surface rounded-xl overflow-hidden cursor-pointer transition-all hover:scale-[1.02] hover:shadow-xl group"
    >
      <div 
        className="h-48 flex items-center justify-center text-white relative"
        style={{ 
          backgroundColor: book.coverColor,
          backgroundImage: book.coverImage ? `url(${book.coverImage})` : 'none',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        {!book.coverImage && (
          <span className="text-4xl font-bold opacity-30 select-none">
            {book.title.charAt(0).toUpperCase()}
          </span>
        )}
        <div className="absolute top-2 right-2 px-2 py-1 rounded bg-black/40 backdrop-blur-md text-[10px] uppercase font-bold tracking-wider">
          {book.status}
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-bold text-gray-100 truncate">{book.title}</h3>
        <p className="text-sm text-gray-400 truncate mb-4">{book.author}</p>
        
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-medium text-gray-400">
            <span>Progresso</span>
            <span className="text-accent">{progress}%</span>
          </div>
          <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
            <div 
              className="h-full bg-accent transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookCard;
