
import React, { useState } from 'react';
import { Book } from '../types';

interface AddBookModalProps {
  onClose: () => void;
  onAdd: (book: Book) => void;
}

const COLORS = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#64748b'];

const AddBookModal: React.FC<AddBookModalProps> = ({ onClose, onAdd }) => {
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    description: '',
    coverColor: COLORS[0],
    coverImage: '',
    status: 'Lendo' as 'Lendo' | 'Concluído'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.author) return;

    const newBook: Book = {
      id: crypto.randomUUID(),
      ...formData,
      chapters: [],
      createdAt: Date.now()
    };
    onAdd(newBook);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-surface w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-gray-800 flex justify-between items-center">
          <h2 className="text-xl font-bold">Novo Livro</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white">&times;</button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">Título</label>
            <input 
              required
              className="w-full bg-dark border border-gray-800 rounded-lg px-4 py-2 focus:outline-none focus:border-accent"
              value={formData.title}
              onChange={e => setFormData({...formData, title: e.target.value})}
              placeholder="Ex: O Hobbit"
            />
          </div>
          
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">Autor</label>
            <input 
              required
              className="w-full bg-dark border border-gray-800 rounded-lg px-4 py-2 focus:outline-none focus:border-accent"
              value={formData.author}
              onChange={e => setFormData({...formData, author: e.target.value})}
              placeholder="Ex: J.R.R. Tolkien"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">Descrição</label>
            <textarea 
              rows={3}
              className="w-full bg-dark border border-gray-800 rounded-lg px-4 py-2 focus:outline-none focus:border-accent resize-none"
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              placeholder="Breve resumo sobre o livro..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">Cor da Capa</label>
              <div className="flex flex-wrap gap-2">
                {COLORS.map(color => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setFormData({...formData, coverColor: color})}
                    className={`w-6 h-6 rounded-full border-2 ${formData.coverColor === color ? 'border-white' : 'border-transparent'}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1">URL da Imagem (Opcional)</label>
              <input 
                className="w-full bg-dark border border-gray-800 rounded-lg px-4 py-2 focus:outline-none focus:border-accent text-sm"
                value={formData.coverImage}
                onChange={e => setFormData({...formData, coverImage: e.target.value})}
                placeholder="https://..."
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">Status</label>
            <div className="flex gap-2">
              {['Lendo', 'Concluído'].map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setFormData({...formData, status: s as any})}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium border ${formData.status === s ? 'bg-accent/10 border-accent text-accent' : 'border-gray-800 text-gray-400 hover:border-gray-700'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 flex gap-3">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-1 px-4 py-2 bg-accent text-white font-bold rounded-lg hover:bg-accent/90 transition-colors shadow-lg shadow-accent/20"
            >
              Adicionar Livro
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddBookModal;
