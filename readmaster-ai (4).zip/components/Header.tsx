
import React from 'react';
import { BookIcon } from './Icons';

const Header: React.FC = () => {
  return (
    <header className="bg-surface border-b border-gray-800 sticky top-0 z-40 backdrop-blur-lg bg-surface/80">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2 group cursor-pointer">
          <div className="p-2 bg-accent rounded-xl text-white shadow-lg shadow-accent/30 group-hover:scale-110 transition-transform">
            <BookIcon />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tighter text-white">READMASTER <span className="text-accent">AI</span></h1>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest leading-none">Smart Reading</p>
          </div>
        </div>
        
        <div className="hidden sm:flex items-center gap-6">
          <nav className="flex gap-4">
            <a href="#" className="text-sm font-medium text-gray-400 hover:text-white">Explorar</a>
            <a href="#" className="text-sm font-medium text-white">Minha Estante</a>
          </nav>
          <div className="h-8 w-[1px] bg-gray-800" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent font-bold text-xs">
              RM
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
