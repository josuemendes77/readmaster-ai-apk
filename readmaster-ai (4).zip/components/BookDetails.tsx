
import React, { useState } from 'react';
import { Book, Chapter, Summary } from '../types';
import { storage } from '../services/storage';
import { generateChapterSummary } from '../services/gemini';
import { ChevronLeftIcon, TrashIcon, PlusIcon, SparklesIcon } from './Icons';

interface BookDetailsProps {
  book: Book;
  onBack: () => void;
  onUpdate: (book: Book) => void;
  onDelete: (id: string) => void;
}

const BookDetails: React.FC<BookDetailsProps> = ({ book, onBack, onUpdate, onDelete }) => {
  const [selectedChapterId, setSelectedChapterId] = useState<string | null>(book.chapters[0]?.id || null);
  const [newChapterTitle, setNewChapterTitle] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const activeChapter = book.chapters.find(c => c.id === selectedChapterId);

  const addChapter = () => {
    if (!newChapterTitle) return;
    const newChapter: Chapter = {
      id: crypto.randomUUID(),
      title: newChapterTitle,
      order: book.chapters.length + 1,
      content: '',
      personalNotes: '',
      isCompleted: false
    };
    const updatedBook = { ...book, chapters: [...book.chapters, newChapter] };
    onUpdate(updatedBook);
    setNewChapterTitle('');
    setSelectedChapterId(newChapter.id);
  };

  const updateActiveChapter = (updates: Partial<Chapter>) => {
    if (!selectedChapterId) return;
    const updatedChapters = book.chapters.map(c => 
      c.id === selectedChapterId ? { ...c, ...updates } : c
    );
    onUpdate({ ...book, chapters: updatedChapters });
  };

  const handleGenerateSummary = async () => {
    if (!activeChapter || !activeChapter.content) {
      alert("Adicione o conteúdo do capítulo primeiro!");
      return;
    }

    setIsGenerating(true);
    try {
      const summary = await generateChapterSummary(activeChapter.content);
      updateActiveChapter({ summary, isCompleted: true });
    } catch (err) {
      alert("Falha ao gerar resumo. Verifique sua chave de API.");
    } finally {
      setIsGenerating(false);
    }
  };

  const deleteBook = () => {
    if (confirm(`Tem certeza que deseja excluir "${book.title}"?`)) {
      onDelete(book.id);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-4 md:py-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header Info */}
      <div className="flex flex-col md:flex-row gap-8 items-start">
        <button 
          onClick={onBack}
          className="p-2 bg-surface rounded-full hover:bg-gray-800 transition-colors"
        >
          <ChevronLeftIcon />
        </button>
        
        <div 
          className="w-32 h-48 md:w-48 md:h-72 rounded-xl flex-shrink-0 shadow-2xl"
          style={{ 
            backgroundColor: book.coverColor,
            backgroundImage: book.coverImage ? `url(${book.coverImage})` : 'none',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />

        <div className="flex-1 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight">{book.title}</h1>
              <p className="text-xl text-gray-400 font-medium">{book.author}</p>
            </div>
            <button 
              onClick={deleteBook}
              className="p-3 text-red-400 hover:bg-red-400/10 rounded-xl transition-colors"
              title="Excluir Livro"
            >
              <TrashIcon />
            </button>
          </div>
          <p className="text-gray-300 leading-relaxed max-w-2xl">{book.description}</p>
          
          <div className="flex items-center gap-2">
            <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest ${book.status === 'Lendo' ? 'bg-accent/20 text-accent border border-accent/50' : 'bg-green-500/20 text-green-400 border border-green-500/50'}`}>
              {book.status}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Chapters Sidebar */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-surface rounded-2xl p-6 border border-gray-800 shadow-inner">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <span className="w-1.5 h-6 bg-accent rounded-full" />
              Capítulos
            </h3>
            
            <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
              {book.chapters.map((chapter) => (
                <button
                  key={chapter.id}
                  onClick={() => setSelectedChapterId(chapter.id)}
                  className={`w-full text-left p-4 rounded-xl transition-all border ${selectedChapterId === chapter.id ? 'bg-accent/10 border-accent text-accent' : 'bg-dark/50 border-gray-800 text-gray-400 hover:bg-dark hover:border-gray-700'}`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-semibold truncate">{chapter.title}</span>
                    {chapter.isCompleted && (
                      <span className="text-[10px] bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full uppercase">Lido</span>
                    )}
                  </div>
                </button>
              ))}
              {book.chapters.length === 0 && (
                <p className="text-sm text-gray-500 italic text-center py-4">Nenhum capítulo adicionado.</p>
              )}
            </div>

            <div className="mt-6 flex gap-2">
              <input 
                placeholder="Título do novo capítulo..."
                className="flex-1 bg-dark border border-gray-800 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent"
                value={newChapterTitle}
                onChange={e => setNewChapterTitle(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addChapter()}
              />
              <button 
                onClick={addChapter}
                className="p-2 bg-accent text-white rounded-lg hover:bg-accent/90 transition-shadow shadow-lg shadow-accent/20"
              >
                <PlusIcon />
              </button>
            </div>
          </div>
        </div>

        {/* Chapter Content / Workspace */}
        <div className="lg:col-span-8">
          {activeChapter ? (
            <div className="space-y-6">
              {/* Content Input */}
              <div className="bg-surface rounded-2xl p-6 border border-gray-800">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold">Conteúdo para Resumo</h3>
                  <button
                    onClick={handleGenerateSummary}
                    disabled={isGenerating || !activeChapter.content}
                    className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-lg font-bold text-sm hover:bg-accent/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {isGenerating ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        IA Pensando...
                      </>
                    ) : (
                      <>
                        <SparklesIcon />
                        Gerar Resumo IA
                      </>
                    )}
                  </button>
                </div>
                <textarea 
                  className="w-full bg-dark border border-gray-800 rounded-xl p-4 min-h-[150px] focus:outline-none focus:border-accent text-gray-200 leading-relaxed"
                  placeholder="Cole aqui o texto do capítulo para que a IA possa resumir..."
                  value={activeChapter.content}
                  onChange={e => updateActiveChapter({ content: e.target.value })}
                />
              </div>

              {/* Summary Display */}
              {activeChapter.summary && (
                <div className="bg-gradient-to-br from-surface to-dark rounded-2xl p-8 border border-accent/20 shadow-2xl space-y-6">
                  <div className="flex items-center gap-3 border-b border-gray-800 pb-4">
                    <div className="p-2 bg-accent/20 rounded-lg text-accent">
                      <SparklesIcon />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">Resumo Inteligente</h3>
                      <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">Gerado por ReadMaster AI</p>
                    </div>
                  </div>
                  
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeChapter.summary.bulletPoints.map((point, i) => (
                      <li key={i} className="flex gap-3 text-gray-300 text-sm leading-snug">
                        <span className="text-accent font-bold mt-1 shrink-0">•</span>
                        {point}
                      </li>
                    ))}
                  </ul>

                  <div className="bg-accent/5 p-6 rounded-xl border border-accent/10">
                    <p className="text-gray-200 italic leading-relaxed text-sm">
                      "{activeChapter.summary.finalParagraph}"
                    </p>
                  </div>
                </div>
              )}

              {/* Personal Notes */}
              <div className="bg-surface rounded-2xl p-6 border border-gray-800">
                <h3 className="text-lg font-bold mb-4">Minhas Notas</h3>
                <textarea 
                  className="w-full bg-dark border border-gray-800 rounded-xl p-4 min-h-[120px] focus:outline-none focus:border-accent text-gray-200"
                  placeholder="O que você achou desse capítulo? Anote seus pensamentos aqui..."
                  value={activeChapter.personalNotes}
                  onChange={e => updateActiveChapter({ personalNotes: e.target.value })}
                />
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-12 bg-surface/50 rounded-2xl border border-dashed border-gray-800">
              <div className="p-4 bg-gray-800/50 rounded-full mb-4">
                <PlusIcon />
              </div>
              <h3 className="text-xl font-bold text-gray-400">Selecione ou adicione um capítulo</h3>
              <p className="text-gray-500 text-sm mt-2">Comece sua jornada de leitura organizando os capítulos.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookDetails;
