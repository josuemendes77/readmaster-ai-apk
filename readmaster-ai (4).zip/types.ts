
export interface Summary {
  bulletPoints: string[];
  finalParagraph: string;
  generatedAt: number;
}

export interface Chapter {
  id: string;
  title: string;
  order: number;
  content: string; // The text used for summary
  summary?: Summary;
  personalNotes: string;
  isCompleted: boolean;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  description: string;
  coverColor: string;
  coverImage?: string;
  status: 'Lendo' | 'Concluído';
  chapters: Chapter[];
  createdAt: number;
}

export type View = 'home' | 'book-details' | 'add-book';
