
import React, { useState, useEffect } from 'react';
import { Book, View } from './types';
import { storage } from './services/storage';
import Header from './components/Header';
import BookCard from './components/BookCard';
import AddBookModal from './components/AddBookModal';
import BookDetails from './components/BookDetails';
import { PlusIcon } from './components/Icons';

const App: React.FC = () => {
  const [books, setBooks] = useState<Book[]>([]);
  const [view, setView] = useState<View>('home');
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    setBooks(storage.getBooks());
  }, []);

  const handleAddBook = (book: Book) => {
    storage.addBook(book);
    setBooks([...books, book]);
    setIsModalOpen(false);
  };

  const handleUpdateBook = (updatedBook: Book) => {
    storage.updateBook(updatedBook);
    setBooks(books.map(b => b.id === updatedBook.id ? updatedBook : b));
  };

  const handleDeleteBook = (id: string) => {
    storage.deleteBook(id);
    setBooks(books.filter(b => b.id !== id));
    setView('home');
    setSelectedBookId(null);
  };

  const openBookDetails = (id: string) => {
    setSelectedBookId(id);
    setView('book-details');
  };

  const selectedBook = books.find(b => b.id === selectedBookId);

  return (
    <div className="min-h-screen bg-dark pb-20">
      <Header />
      
      <main className="container mx-auto px-4 mt-8">
        {view === 'home' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-extrabold text-white">Sua Estante</h2>
                <p className="text-gray-500">Acompanhe seu progresso e gere resumos automáticos.</p>
              </div>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="bg-accent text-white flex items-center gap-2 px-6 py-3 rounded-xl font-bold shadow-lg shadow-accent/20 hover:bg-accent/90 transition-all hover:scale-105"
              >
                <PlusIcon />
                <span>Novo Livro</span>
              </button>
            </div>

            {books.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {books.map(book => (
                  <BookCard 
                    key={book.id} 
                    book={book} 
                    onClick={() => openBookDetails(book.id)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-surface rounded-3xl border border-dashed border-gray-800">
                <div className="text-gray-600 mb-4 inline-block p-6 bg-dark rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-gray-400">Sua biblioteca está vazia</h3>
                <p className="text-gray-500 max-w-sm mx-auto mt-2">Adicione seu primeiro livro para começar a gerenciar suas leituras com IA.</p>
                <button 
                  onClick={() => setIsModalOpen(true)}
                  className="mt-8 text-accent font-bold hover:underline"
                >
                  Adicionar Livro Agora
                </button>
              </div>
            )}
          </div>
        )}

        {view === 'book-details' && selectedBook && (
          <BookDetails 
            book={selectedBook} 
            onBack={() => setView('home')}
            onUpdate={handleUpdateBook}
            onDelete={handleDeleteBook}
          />
        )}
      </main>

      {isModalOpen && (
        <AddBookModal 
          onClose={() => setIsModalOpen(false)} 
          onAdd={handleAddBook}
        />
      )}

      {/* Persistent CTA for Mobile */}
      {view === 'home' && (
        <div className="fixed bottom-6 right-6 md:hidden">
          <button 
             onClick={() => setIsModalOpen(true)}
             className="w-14 h-14 bg-accent rounded-full flex items-center justify-center text-white shadow-2xl shadow-accent/40 animate-bounce"
          >
            <PlusIcon />
          </button>
        </div>
      )}
    </div>
  );
};

export default App;
